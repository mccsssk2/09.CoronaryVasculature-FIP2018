#!/bin/bash
#SBATCH -t 2-00:00
#SBATCH --mem=16G
./mes 0.1
# ./mes 0.5
# ./mes 1.0 
# ./mes 2.0
# ./mes 3.0
# ./mes 4.0
