if(whichCase==3 && order == 10 && segLabel < 1){ // this may be a circle.

if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 61.5; tNode->y_cood = 34; tNode->z_cood = 2; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-1) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 61.5; tNode->y_cood = 33; tNode->z_cood = 3; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-2) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 61; tNode->y_cood = 30; tNode->z_cood = 4; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-3) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 61; tNode->y_cood = 27; tNode->z_cood = 5; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-4) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 60.5; tNode->y_cood = 24; tNode->z_cood = 6; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-5) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 59.5; tNode->y_cood = 21; tNode->z_cood = 8; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-6) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 58; tNode->y_cood = 18; tNode->z_cood = 11; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-7) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 56; tNode->y_cood = 15; tNode->z_cood = 13; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-8) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 52.5; tNode->y_cood = 11.5; tNode->z_cood = 17; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-9) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 50.5; tNode->y_cood = 10; tNode->z_cood = 20; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-10) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 49.5; tNode->y_cood = 10; tNode->z_cood = 24; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-11) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 46; tNode->y_cood = 8; tNode->z_cood = 27; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-12) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 43; tNode->y_cood = 7; tNode->z_cood = 30; tNode->onOff = 1;	
	}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-13) ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 43; tNode->y_cood = 7.5; tNode->z_cood = 33; tNode->onOff = 1;	
	}
	else
	{
	tNode->assignedOrNot = 0;  tNode->x_cood = -1; tNode->y_cood = -1; tNode->z_cood = -1; tNode->onOff = 0;
	}
	
}

