if(whichCase==1 && order == 10 && segLabel==1 ){
	

	if(numberOfSegmentsInElement==(9)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 34; tNode->y_cood = 61.5; tNode->z_cood = 3.0; tNode->onOff = 1; 
		segLabel=1;
		if(debug)
		printf("%d \n", numberOfSegmentsInElement);
		
	}
	else if(numberOfSegmentsInElement==(9-1)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 34.5; tNode->y_cood = 62; tNode->z_cood = 6.0; tNode->onOff = 1; 
		segLabel=1;		
		if(debug)	
		printf("%d \n", numberOfSegmentsInElement);	
	}
	else if(numberOfSegmentsInElement==(9-2)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 35; tNode->y_cood = 61.5; tNode->z_cood = 10.0; tNode->onOff = 1; 
		segLabel=1;		
		if(debug)	
		printf("%d \n", numberOfSegmentsInElement);	
	}
	else if(numberOfSegmentsInElement==(9-3)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 36; tNode->y_cood = 61.5; tNode->z_cood = 12.0; tNode->onOff = 1; 
		segLabel=1;		
		if(debug)	
		printf("%d \n", numberOfSegmentsInElement);	
	}
	else if(numberOfSegmentsInElement==(9-4)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 38; tNode->y_cood = 61; tNode->z_cood = 13.5; tNode->onOff = 1; 
		segLabel=1;		
		if(debug)	
		printf("%d \n", numberOfSegmentsInElement);	
	}
	else if(numberOfSegmentsInElement==(9-5)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 39; tNode->y_cood = 60.5; tNode->z_cood = 15.0; tNode->onOff = 1; 
		segLabel=1;		
		if(debug)	
		printf("%d \n", numberOfSegmentsInElement);	
	}
	else if(numberOfSegmentsInElement==(9-6)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 41; tNode->y_cood = 59.5; tNode->z_cood = 17.0; tNode->onOff = 1; 
		segLabel=1;		
		if(debug)	
		printf("%d \n", numberOfSegmentsInElement);	
	}
	else if(numberOfSegmentsInElement==(9-7)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 42; tNode->y_cood = 59; tNode->z_cood = 18.0; tNode->onOff = 1;
		segLabel=1;		
		if(debug)	
		printf("%d \n", numberOfSegmentsInElement);	
	}
	else if(numberOfSegmentsInElement==(9-8)    ){
		tNode->assignedOrNot = 1;  tNode->x_cood = 44; tNode->y_cood = 58; tNode->z_cood = 20; tNode->onOff = 1;
		segLabel=1;	 
		if(debug)	
		printf("%d \n", numberOfSegmentsInElement);	
	}

} // end of RCA septal.
