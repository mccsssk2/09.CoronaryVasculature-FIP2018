			tNode->right = makeKassabTree( numberOfSegmentsInElement2, nodeData, order2, segmentElementRatio_mean, segmentElementRatio_SD , cuprob_conn , segmentLengths_mean, segmentLengths_SD, elementDiameters_mean , tNode->data, whichCase, stopOrder, startOrder, amx, -1.0, -1.0, -1.0  , tNode->onOff, tNode->assignedOrNot, t0, tNode->strahler, segLabel );

