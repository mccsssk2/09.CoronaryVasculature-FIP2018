if(whichCase==1 && order == 11 && segLabel<1){  // this is 1 element.

if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order]))    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 28; tNode->y_cood = 59; tNode->z_cood = 2.0; tNode->onOff = 1; 
	if(debug)
	printf("%d \n", numberOfSegmentsInElement);
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-1)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 32; tNode->y_cood = 59; tNode->z_cood = 2.0; tNode->onOff = 1; 
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-2)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 36; tNode->y_cood = 59; tNode->z_cood = 2.0; tNode->onOff = 1; 
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-3)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 40; tNode->y_cood = 59; tNode->z_cood = 2.0; tNode->onOff = 1; 
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-4)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 44; tNode->y_cood = 59; tNode->z_cood = 2.0; tNode->onOff = 1; 
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-5)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 48; tNode->y_cood = 57.5; tNode->z_cood = 2.0; tNode->onOff = 1; 
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-6)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 50.75; tNode->y_cood = 60; tNode->z_cood = 2.0; tNode->onOff = 1; 
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-7)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 54.75; tNode->y_cood = 65; tNode->z_cood = 2.0; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-8)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 53; tNode->y_cood = 68; tNode->z_cood = 3.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-9)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 50.5; tNode->y_cood = 72; tNode->z_cood = 7; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-10)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 47.5; tNode->y_cood = 75; tNode->z_cood = 10.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-11)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 43; tNode->y_cood = 78; tNode->z_cood = 14.3; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-12)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 38; tNode->y_cood = 80; tNode->z_cood = 18; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-13)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 33; tNode->y_cood = 80; tNode->z_cood = 21; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-14)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 30; tNode->y_cood = 79; tNode->z_cood = 24; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-15)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 26; tNode->y_cood = 77.5; tNode->z_cood = 26.3; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-16)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 21; tNode->y_cood = 74.5; tNode->z_cood = 26.3; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-17)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 18; tNode->y_cood = 72; tNode->z_cood = 27; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-18)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 15; tNode->y_cood = 68; tNode->z_cood = 27; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-19)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 13; tNode->y_cood = 65; tNode->z_cood = 28; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-20)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 11; tNode->y_cood = 61; tNode->z_cood = 28.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-21)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 9.5; tNode->y_cood = 57; tNode->z_cood = 29; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-22)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 8.5; tNode->y_cood = 53; tNode->z_cood = 29.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-23)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 7.5; tNode->y_cood = 49.5; tNode->z_cood = 29; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-24)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 6.75; tNode->y_cood = 46; tNode->z_cood = 28.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-25)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 6; tNode->y_cood = 43; tNode->z_cood = 28; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-26)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 5.5; tNode->y_cood = 39; tNode->z_cood = 27.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-27)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 4.5; tNode->y_cood = 35; tNode->z_cood = 27; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-28)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 4.4; tNode->y_cood = 32; tNode->z_cood = 26.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-29)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 4.2; tNode->y_cood = 29; tNode->z_cood = 26; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-30)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 4.8; tNode->y_cood = 25; tNode->z_cood = 25.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-31)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 5.7; tNode->y_cood = 22; tNode->z_cood = 25.5; tNode->onOff = 1;
	if(debug)	
	printf("%d \n", numberOfSegmentsInElement);	
}
else if(numberOfSegmentsInElement==((int)(segmentElementRatio_mean[order])-32)    ){
	tNode->assignedOrNot = 1;  tNode->x_cood = 8.5; tNode->y_cood = 18; tNode->z_cood = 25; tNode->onOff = 1;
	if(debug)	
	printf("Last in RCA: %d \n", numberOfSegmentsInElement);	
	if(debug)	
	printf("last node of RCA assigned here.\n");
}
else
{
tNode->assignedOrNot = 0;  tNode->x_cood = -1; tNode->y_cood = -1; tNode->z_cood = -1; tNode->onOff = 0;
if(debug)
printf("some nodes on RCA O(11) got unassigned randomly!! %d %d\n", numberOfSegmentsInElement, tNode->whichCase);
}

} // end of whichcase = 1, RCA main O(11).
