#!/bin/bash

./srk3d 1
./srk3d 2
./srk3d 3
./fibs
