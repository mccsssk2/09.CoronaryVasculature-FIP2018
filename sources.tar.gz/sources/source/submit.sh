#!/bin/bash
#SBATCH -t 2-00:00
#SBATCH --mem=16G
./vasc 4 6
